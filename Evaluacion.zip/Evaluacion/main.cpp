#include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>
void display(void)
{
   



 glClear(GL_COLOR_BUFFER_BIT);
 glColor3f(1.0f,1.0f,1.0f);
  glPointSize(2);

    glBegin(GL_LINES);
  

      
          /// CUADRO GRANDE
          
    glVertex3f(-9.0f,9.0f,0.0f); 
    glVertex3f(9.0f,9.0f,0.0f);

    glVertex3f(9.0f,9.0f,0.0f);


    glVertex3f(9.0f,-9.0f,0.0f);

     glVertex3f(9.0f,-9.0f,0.0f);

    glVertex3f(-9.0f,-9.0f,0.0f);
    glVertex3f(-9.0f,-9.0f,0.0f);
    glVertex3f(-9.0f,9.0f,0.0f);
    glVertex3f(0.0f,9.0f,0.0f);
    glVertex3f(0.0f,-9.0f,0.0f);
          
          
            /// Area 1
       glVertex3f(-9.0f,2.0f,0.0f);    
       glVertex3f(-7.0f,2.0f,0.0f); 
     
        glVertex3f(-7.0f,2.0f,0.0f); 
            
        glVertex3f(-7.0f,-2.0f,0.0f);
         glVertex3f(-7.0f,-2.0f,0.0f);
         glVertex3f(-9.0f,-2.0f,0.0f);
         
         
          /// Area 2
          glVertex3f(-9.0f,5.0f,0.0f);    
         glVertex3f(-6.0f,5.0f,0.0f); 
      
         glVertex3f(-6.0f,5.0f,0.0f); 
            
         glVertex3f(-6.0f,-5.0f,0.0f);
         glVertex3f(-6.0f,-5.0f,0.0f);
         glVertex3f(-9.0f,-5.0f,0.0f);
         
         
          
            /// Area 1
       glVertex3f(9.0f,2.0f,0.0f);    
       glVertex3f(7.0f,2.0f,0.0f); 
     
        glVertex3f(7.0f,2.0f,0.0f); 
            
        glVertex3f(7.0f,-2.0f,0.0f);
         glVertex3f(7.0f,-2.0f,0.0f);
         glVertex3f(9.0f,-2.0f,0.0f);
         
         
          /// Area 2
          glVertex3f(9.0f,5.0f,0.0f);    
         glVertex3f(6.0f,5.0f,0.0f); 
      
         glVertex3f(6.0f,5.0f,0.0f); 
            
         glVertex3f(6.0f,-5.0f,0.0f);
         glVertex3f(6.0f,-5.0f,0.0f);
         glVertex3f(9.0f,-5.0f,0.0f);
         
         
  
           glEnd();
           glFlush();
    GLfloat angulo;
 
    
    glBegin(GL_POINTS); //GL_Lines para ver la circunferencias con lineas
   /* for (i=0; i<360; i+=1)
	{
		angulo =i*M_PI/180.0f; //grados a radianes
	
		glVertex3f(cos(angulo), sin(angulo),0.0f);
     }
    **/
    
    
    
          /// ESQUINA
          
    glPointSize(2);
     double i;
     double radio , cx,cy,puntox=0,puntoy=0;
     radio=3;
     for (i=0; i<= 8 ; i+=0.001)
     {
		 cx=radio*cos(i)+puntox;
		  cy=radio*sin(i)+puntoy;
		   glVertex2f(cx,cy);
	 }
	 
	 
	 
	          glEnd();
	           glBegin(GL_POINTS);

	glBegin(GL_POINTS);
	 glPointSize(0.01);
	

	GLfloat angulo2;
    int j;
    /// ESQUINA
    glBegin(GL_POINTS);
	for (j=270; j<360;j+=1)
	{
		angulo2 =j*M_PI/180.0f;//grados a radianes
		glVertex3f(0.0, 0.0, 0.0);
		glVertex3f(1*cos(angulo2)-9,  1*sin(angulo2)+9, 0.0f);
	}
    
    glEnd();
    
    
    glBegin(GL_POINTS);
	 glPointSize(0.01);
	 
    /// ESQUINA
    glBegin(GL_POINTS);
	for (j=180; j<270;j+=1)
	{
		angulo2 =j*M_PI/180.0f;//grados a radianes
		glVertex3f(0.0, 0.0, 0.0);
		glVertex3f(1*cos(angulo2)+9,  1*sin(angulo2)+9, 0.0f);
	}
    
    glEnd();
     /// ESQUINA
    glBegin(GL_POINTS);
	 glPointSize(0.01);
	 
   
    glBegin(GL_POINTS);
	for (j=0; j<90;j+=1)
	{
		angulo2 =j*M_PI/180.0f;//grados a radianes
		glVertex3f(0.0, 0.0, 0.0);
		glVertex3f(1*cos(angulo2)-9,  1*sin(angulo2)-9, 0.0f);
	}
    
    glEnd();
    
     /// ESQUINA
    glBegin(GL_POINTS);
	 glPointSize(0.01);
	 
   
    glBegin(GL_POINTS);
	for (j=90; j<180;j+=1)
	{
		angulo2 =j*M_PI/180.0f;//grados a radianes
		glVertex3f(0.0, 0.0, 0.0);
		glVertex3f(1*cos(angulo2)+9,  1*sin(angulo2)-9, 0.0f);
	}
    
  	//medio luna
	
	glBegin(GL_POINTS);
	 glPointSize(0.01);
	 
   
    glBegin(GL_POINTS);
	for (j=270; j<450;j+=1)
	{
		angulo2 =j*M_PI/180.0f;//grados a radianes
		glVertex3f(0.0, 0.0, 0.0);
		glVertex3f(1*cos(angulo2)-6,  2.5*sin(angulo2), 0.0f);
	}
    
    glEnd();
    
	
	
	//medio luna


	glBegin(GL_POINTS);
	 glPointSize(0.01);
	 
   
    glBegin(GL_POINTS);
	for (j=90; j<270;j+=1)
	{
		angulo2 =j*M_PI/180.0f;//grados a radianes
		glVertex3f(0.0, 0.0, 0.0);
		glVertex3f(1*cos(angulo2)+6,  2.5*sin(angulo2), 0.0f);
	}
    
    glEnd();

              
         glEnd();
         
              glPointSize(10);
          glBegin(GL_POINTS);
      
           glVertex2f(0,0);
  glVertex2f(-6.5,0);
  glVertex2f(6.5,0);
  
  
  
  
  
  //JUGADORES 
  
   glColor3f(1.0f,0.0f,1.0f);
  glVertex2f(-7,7);
  glVertex2f(-7,4);
  glVertex2f(-7,-4);
  glVertex2f(-7,-7);
  
    
  glVertex2f(-4,7);
  glVertex2f(-4,4);
  glVertex2f(-4,-4);
  glVertex2f(-4,-7);
  
    
  glVertex2f(-2,3);
  glVertex2f(-2,-3);
     glVertex2f(-8,0);
  
   glColor3f(0.0f,1.0f,1.0f);
  
    glVertex2f(7,7);
  glVertex2f(7,4);
  glVertex2f(7,-4);
  glVertex2f(7,-7);
  
    
  glVertex2f(4,7);
  glVertex2f(4,4);
  glVertex2f(4,-4);
  glVertex2f(4,-7);
  
    
  glVertex2f(2,3);
  glVertex2f(2,-3);
  
  
    glVertex2f(8,0);
 
             glEnd();
          
    
          
 
    glFlush ();

    

}
void init (void){   
	glClearColor(0.0, 0.6, 0.0, 0.0);
    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-10.0, 10.0, -10.0, 10.0, -10.0, 10.0);
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (1100, 800);
    glutInitWindowPosition (100, 100);
    glutCreateWindow ("Puntos OpenGL");
    init ();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
